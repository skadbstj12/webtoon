import React from 'react'

const DetailPage = () => {
    return (
        <div>
            asfads
        </div>
    )
}

export default DetailPage
